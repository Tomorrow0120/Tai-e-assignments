/*
 * Tai-e: A Static Analysis Framework for Java
 *
 * Copyright (C) 2022 Tian Tan <tiantan@nju.edu.cn>
 * Copyright (C) 2022 Yue Li <yueli@nju.edu.cn>
 *
 * This file is part of Tai-e.
 *
 * Tai-e is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation, either version 3
 * of the License, or (at your option) any later version.
 *
 * Tai-e is distributed in the hope that it will be useful,but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General
 * Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with Tai-e. If not, see <https://www.gnu.org/licenses/>.
 */

package pascal.taie.analysis.pta.cs;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import pascal.taie.World;
import pascal.taie.analysis.graph.callgraph.CallGraphs;
import pascal.taie.analysis.graph.callgraph.CallKind;
import pascal.taie.analysis.graph.callgraph.Edge;
import pascal.taie.analysis.pta.PointerAnalysisResult;
import pascal.taie.analysis.pta.PointerAnalysisResultImpl;
import pascal.taie.analysis.pta.core.cs.CSCallGraph;
import pascal.taie.analysis.pta.core.cs.context.Context;
import pascal.taie.analysis.pta.core.cs.element.ArrayIndex;
import pascal.taie.analysis.pta.core.cs.element.CSCallSite;
import pascal.taie.analysis.pta.core.cs.element.CSManager;
import pascal.taie.analysis.pta.core.cs.element.CSMethod;
import pascal.taie.analysis.pta.core.cs.element.CSObj;
import pascal.taie.analysis.pta.core.cs.element.CSVar;
import pascal.taie.analysis.pta.core.cs.element.InstanceField;
import pascal.taie.analysis.pta.core.cs.element.MapBasedCSManager;
import pascal.taie.analysis.pta.core.cs.element.Pointer;
import pascal.taie.analysis.pta.core.cs.element.StaticField;
import pascal.taie.analysis.pta.core.cs.selector.ContextSelector;
import pascal.taie.analysis.pta.core.heap.HeapModel;
import pascal.taie.analysis.pta.core.heap.Obj;
import pascal.taie.analysis.pta.pts.PointsToSet;
import pascal.taie.analysis.pta.pts.PointsToSetFactory;
import pascal.taie.config.AnalysisOptions;
import pascal.taie.ir.IR;
import pascal.taie.ir.exp.InvokeExp;
import pascal.taie.ir.exp.Var;
import pascal.taie.ir.stmt.Copy;
import pascal.taie.ir.stmt.Invoke;
import pascal.taie.ir.stmt.LoadArray;
import pascal.taie.ir.stmt.LoadField;
import pascal.taie.ir.stmt.New;
import pascal.taie.ir.stmt.StmtVisitor;
import pascal.taie.ir.stmt.StoreArray;
import pascal.taie.ir.stmt.StoreField;
import pascal.taie.language.classes.JField;
import pascal.taie.language.classes.JMethod;
import pascal.taie.language.type.Type;

class Solver {

    private static final Logger logger = LogManager.getLogger(Solver.class);

    private final AnalysisOptions options;

    private final HeapModel heapModel;

    private final ContextSelector contextSelector;

    private CSManager csManager;

    private CSCallGraph callGraph;

    private PointerFlowGraph pointerFlowGraph;

    private WorkList workList;

    private PointerAnalysisResult result;

    Solver(AnalysisOptions options, HeapModel heapModel,
           ContextSelector contextSelector) {
        this.options = options;
        this.heapModel = heapModel;
        this.contextSelector = contextSelector;
    }

    void solve() {
        initialize();
        analyze();
    }

    private void initialize() {
        csManager = new MapBasedCSManager();
        callGraph = new CSCallGraph(csManager);
        pointerFlowGraph = new PointerFlowGraph();
        workList = new WorkList();
        // process program entry, i.e., main method
        Context defContext = contextSelector.getEmptyContext();
        JMethod main = World.get().getMainMethod();
        CSMethod csMethod = csManager.getCSMethod(defContext, main);
        callGraph.addEntryMethod(csMethod);
        addReachable(csMethod);
    }

    /**
     * Processes new reachable context-sensitive method.
     */
    private void addReachable(CSMethod csMethod) {
        // TODO - finish me

        if (callGraph.addReachableMethod(csMethod)) {
            StmtProcessor processor = new StmtProcessor(csMethod);
            csMethod.getMethod().getIR().forEach(stmt -> stmt.accept(processor));
        }

    }

    /**
     * Processes the statements in context-sensitive new reachable methods.
     */
    private class StmtProcessor implements StmtVisitor<Void> {

        private final CSMethod csMethod;

        private final Context context;

        private StmtProcessor(CSMethod csMethod) {
            this.csMethod = csMethod;
            this.context = csMethod.getContext();
        }

        // TODO - if you choose to implement addReachable()
        //  via visitor pattern, then finish me

        @Override
        public Void visit(New stmt) {
            CSVar target = csManager.getCSVar(context, stmt.getLValue());

            Obj obj = heapModel.getObj(stmt);
            Context heapContext = contextSelector.selectHeapContext(csMethod, obj);
            CSObj csObj = csManager.getCSObj(heapContext, obj);

            workList.addEntry(target, PointsToSetFactory.make(csObj));
            return null;
        }

        @Override
        public Void visit(Copy stmt) {
            CSVar source = csManager.getCSVar(context, stmt.getRValue());
            CSVar target = csManager.getCSVar(context, stmt.getLValue());
            addPFGEdge(source, target);
            return null;
        }

        @Override
        public Void visit(Invoke stmt) {
            if (!stmt.isStatic()) {
                return null;
            }

            JMethod callee = resolveCallee(null, stmt);
            if (callee == null) {
                return null;
            }

            CSCallSite callSite = csManager.getCSCallSite(context, stmt);
            Context calleeContext = contextSelector.selectContext(callSite, callee);
            CSMethod csCallee = csManager.getCSMethod(calleeContext, callee);

            addCallEdge(callSite, csCallee);

            return null;
        }

        @Override
        public Void visit(StoreField stmt) {
            if (stmt.isStatic()) {
                JField field = stmt.getFieldRef().resolve();
                CSVar value = csManager.getCSVar(context, stmt.getRValue());
                addPFGEdge(value, csManager.getStaticField(field));
            }
            return null;
        }

        @Override
        public Void visit(LoadField stmt) {
            if (stmt.isStatic()) {
                JField field = stmt.getFieldRef().resolve();
                CSVar result = csManager.getCSVar(context, stmt.getLValue());
                addPFGEdge(csManager.getStaticField(field), result);
            }
            return null;
        }


    }

    /**
     * Adds an edge "source -> target" to the PFG.
     */
    private void addPFGEdge(Pointer source, Pointer target) {
        // TODO - finish me

        if (pointerFlowGraph.addEdge(source, target)) {
            PointsToSet objects = source.getPointsToSet();
            if (objects != null && !objects.isEmpty()) {
                workList.addEntry(target, objects);
            }
        }

    }

    /**
     * Processes work-list entries until the work-list is empty.
     */
    private void analyze() {
        // TODO - finish me

        while (!workList.isEmpty()) {
            WorkList.Entry entry = workList.pollEntry();
            PointsToSet delta = propagate(entry.pointer(), entry.pointsToSet());
            if (entry.pointer() instanceof CSVar base) {
                Var var = base.getVar();
                Context context = base.getContext();

                for (CSObj obj : delta) {
                    for (StoreArray store : var.getStoreArrays()) {
                        CSVar value = csManager.getCSVar(context, store.getRValue());
                        addPFGEdge(value, csManager.getArrayIndex(obj));
                    }

                    for (LoadArray load : var.getLoadArrays()) {
                        CSVar result = csManager.getCSVar(context, load.getLValue());
                        addPFGEdge(csManager.getArrayIndex(obj), result);
                    }

                    for (StoreField store : var.getStoreFields()) {
                        JField field = store.getFieldRef().resolve();
                        InstanceField target = csManager.getInstanceField(obj, field);
                        CSVar value = csManager.getCSVar(context, store.getRValue());
                        addPFGEdge(value, target);
                    }

                    for (LoadField load : var.getLoadFields()) {
                        JField field = load.getFieldRef().resolve();
                        InstanceField source = csManager.getInstanceField(obj, field);
                        CSVar result = csManager.getCSVar(context, load.getLValue());
                        addPFGEdge(source, result);
                    }

                    processCall(base, obj);
                }
            }
        }

    }

    /**
     * Propagates pointsToSet to pt(pointer) and its PFG successors,
     * returns the difference set of pointsToSet and pt(pointer).
     */
    private PointsToSet propagate(Pointer pointer, PointsToSet pointsToSet) {
        // TODO - finish me
        PointsToSet current = pointer.getPointsToSet();
        if (current == null) {
            current = PointsToSetFactory.make();
            pointer.setPointsToSet(current);
        }

        PointsToSet delta = PointsToSetFactory.make();
        for (CSObj obj : pointsToSet) {
            if (current.addObject(obj)) {
                delta.addObject(obj);
            }
        }

        if (!delta.isEmpty()) {
            for (Pointer successor : pointerFlowGraph.getSuccsOf(pointer)) {
                workList.addEntry(successor, delta);
            }
        }

        return delta;
    }

    /**
     * Processes instance calls when points-to set of the receiver variable changes.
     *
     * @param recv    the receiver variable
     * @param recvObj set of new discovered objects pointed by the variable.
     */
    private void processCall(CSVar recv, CSObj recvObj) {
        // TODO - finish me

        Context callerContext = recv.getContext();

        for (Invoke invoke : recv.getVar().getInvokes()) {
            JMethod callee = resolveCallee(recvObj, invoke);
            if (callee == null) {
                continue;
            }

            CSCallSite callSite = csManager.getCSCallSite(callerContext, invoke);
            Context calleeContext = contextSelector.selectContext(callSite, recvObj, callee);
            CSMethod csCallee = csManager.getCSMethod(calleeContext, callee);

            CSVar thisVar = csManager.getCSVar(calleeContext, callee.getIR().getThis());
            workList.addEntry(thisVar, PointsToSetFactory.make(recvObj));

            addCallEdge(callSite, csCallee);
        }

    }

    private void addCallEdge(CSCallSite callSite, CSMethod callee) {
        Invoke invoke = callSite.getCallSite();
        Edge<CSCallSite, CSMethod> edge =
                new Edge<>(CallGraphs.getCallKind(invoke), callSite, callee);
        if (!callGraph.addEdge(edge)) {
            return;
        }

        addReachable(callee);

        Context callerContext = callSite.getContext();
        Context calleeContext = callee.getContext();
        IR calleeIR = callee.getMethod().getIR();
        InvokeExp invokeExp = invoke.getInvokeExp();
        for (int i = 0; i < invokeExp.getArgCount(); i++) {
            CSVar arg = csManager.getCSVar(callerContext, invokeExp.getArg(i));
            CSVar param = csManager.getCSVar(calleeContext, calleeIR.getParam(i));
            addPFGEdge(arg, param);
        }

        Var result = invoke.getResult();
        if (result != null) {
            CSVar target = csManager.getCSVar(callerContext, result);
            for (Var returnVar : calleeIR.getReturnVars()) {
                CSVar source = csManager.getCSVar(calleeContext, returnVar);
                addPFGEdge(source, target);
            }
        }
    }

    /**
     * Resolves the callee of a call site with the receiver object.
     *
     * @param recv the receiver object of the method call. If the callSite
     *             is static, this parameter is ignored (i.e., can be null).
     * @param callSite the call site to be resolved.
     * @return the resolved callee.
     */
    private JMethod resolveCallee(CSObj recv, Invoke callSite) {
        Type type = recv != null ? recv.getObject().getType() : null;
        return CallGraphs.resolveCallee(type, callSite);
    }

    PointerAnalysisResult getResult() {
        if (result == null) {
            result = new PointerAnalysisResultImpl(csManager, callGraph);
        }
        return result;
    }
}
